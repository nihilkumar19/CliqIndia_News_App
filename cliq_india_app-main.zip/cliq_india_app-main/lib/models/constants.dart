
class Constants {
  static final bookmarkTag = "bookmarked_list";
  static final resentSearchTag = 'recent_search';
  static final notificationTag = 'notifications';
}